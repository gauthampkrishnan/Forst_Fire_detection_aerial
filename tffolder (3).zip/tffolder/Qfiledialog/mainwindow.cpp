#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QDir>
#include <QString>
#include <QMessageBox>
#include <QProcess>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    QString file_name = QFileDialog::getOpenFileName(this,"Open a File",QDir::homePath());
    QMessageBox::information(this,"..","You have selected "+file_name);
}

void MainWindow::on_pushButton_clicked()
{
//    QProcess *process = new QProcess();
//    QString exec = "xterm";
//    process->start(exec);

    QProcess process;
    process.startDetached("/bin/sh", QStringList()<< "/home/rahul/Desktop/commands.sh");
}
